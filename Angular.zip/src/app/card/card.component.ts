import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css'],
})
export class CardComponent implements OnInit {

  Image =
    'https://media.istockphoto.com/vectors/video-player-template-for-web-or-mobile-apps-blogging-vector-id1310634705?k=20&m=1310634705&s=612x612&w=0&h=6ezbTj2MgmVwmQEx6zqmage2m2bWwcRSjiFSQatczK4=';
 

  @Input() dataEntrante: any;
  constructor() {}

  ngOnInit(): void {}
}
