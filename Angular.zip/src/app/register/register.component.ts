import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Usuario } from 'src/interfaces/Usuario';
import { UsuarioProvider } from 'src/providers/usuarioProvider';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  usuario = {} as any;
  userData: any = [];

  async register(usuario: any) {

    if (!usuario.nombre || !usuario.apellido || !usuario.direccion || !usuario.dni) {
      alert('Todos los campos son requeridos!')
      return
    }

    this.usuarioApi.postRegister(usuario).subscribe((data) => {

      if (data.statusCode === 200) {
        alert('registrado exitosamente');
      } else alert(data.error);
    });
  }

  constructor(public usuarioApi: UsuarioProvider, private router: Router) {}

  ngOnInit(): void {
    
  }
}
