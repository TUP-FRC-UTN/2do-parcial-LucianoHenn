import { Component, OnInit } from '@angular/core';
import { Usuario } from 'src/interfaces/Usuario'
import { UsuarioProvider } from "src/providers/usuarioProvider";
import { Router } from '@angular/router';

interface Tarjeta{
  Titulo: string,
  Subtitulo: string,
  Nro?: number,
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  constructor() {
    
  }

  public ArregloTarjetas: Tarjeta[] = [];



  ngOnInit(): void{
    this.ArregloTarjetas = [
      {
        Titulo: "Video 1",
        Subtitulo: "Este es mi video 1",
        Nro: 55
      },
      {
        Titulo: "Video 2",
        Subtitulo: "Este es mi video 2"
      },
      {
        Titulo: "Video 3",
        Subtitulo: "Este es mi video 3"
      },
      {
        Titulo: "Video 4",
        Subtitulo: "Este es mi video 4"
      },
      {
        Titulo: "Video 5",
        Subtitulo: "Este es mi video 5"
      },
      {
        Titulo: "Video 6",
        Subtitulo: "Este es mi video 6"
      }
      
    ]
  }

  title = 'Hola Mundo';
}
