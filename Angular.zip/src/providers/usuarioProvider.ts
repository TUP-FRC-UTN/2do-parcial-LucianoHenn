import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { RUTA_API } from "src/rutaApi";

interface User {
  password: string;
  nombre: string;
  apellido: string;
  dni: string;
  direccion: string;
}

@Injectable()
export class UsuarioProvider {
  baseURL: string = RUTA_API;
  private _options = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': 'true',
    }),
  };

  constructor(private http: HttpClient) {}


  postRegister(usuario: User): Observable<any> {
    const url = 'https://localhost:7112/api/persona';

    const body = JSON.stringify(usuario);
    console.log('body', body);
    return this.http.post(url, body, this._options);
  }

  
}